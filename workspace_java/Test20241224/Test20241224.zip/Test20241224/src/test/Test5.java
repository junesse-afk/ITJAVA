package test;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Test5 {

	public static void main(String[] args) {
//		보조 스트림
//		입력 => Buffered 스트림 모아서 사용
//		Buffered 스트림 모아서 => 출력
		
		try {
			FileInputStream fileInputStream 
			= new FileInputStream("") ;
			FileOutputStream fileOutputStream
			= new FileOutputStream("");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
